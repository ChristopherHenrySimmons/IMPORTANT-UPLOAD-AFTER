<?php 
$conn = new PDO('mysql:host=localhost; dbname=upload_image','root', ''); 
?>